import {Injectable} from "@angular/core";
import {Http} from '@angular/http';
import 'rxjs';
import {AppConstants} from '../common/app.constants';

//Decorate the class as Injectable
@Injectable()
export class DataService {
    private cartItems=[];

    constructor(private httpSvc : Http) {

    }

    getCartItems() {
        return this.cartItems;
    }

    handleCart(data) {
        var isItemExistInCart=false;
        this.cartItems.forEach(x=> {
            if(x._id == data._id) {
                x=data;
                isItemExistInCart=true;
            }
        });

        if(!isItemExistInCart) {
            this.cartItems.push(data);
        } 
    }

    handleCartRemove(data) {
        var isItemExistInCart=false;
        var index=-1;
        var id=0;
        this.cartItems.forEach(x=> {
            id++;
            if(x._id == data._id) {
                index=id;
                x=data;
                if(x.quantity >0) {
                    isItemExistInCart=true;
                }
            }
        });

        if(isItemExistInCart) {

            this.cartItems.splice(index-1,1);
        } 
    }

    getCountries() : Array<any> {
        return  [ 
            {name:"America", code:"US"},
            {name:"India", code:"IN"},
            {name:"Russia", code:"RS"}, 
            {name:"South Africa", code:"SA"}
        ];
    }

    getCountriesFromAPi() {
        let url="http://localhost:3000/countries";
        return this.httpSvc.get(url)
        .map(data=>{//data comes in a stream which needs to converted into json format
            return data.json();
        }, 
        err=>{
            return err.json();
        })
        .toPromise()//The toPromise call needs the import 'rxjs'
    }

    getDataFromAPi(url) {
        let uri = AppConstants.BASE_URL + url;
        return this.httpSvc.get(uri)
        .map(data=>{//data comes in a stream which needs to converted into json format
            return data.json();
        }, 
        err=>{
            return err.json();
        })
        .toPromise()//The toPromise call needs the import 'rxjs'
    }

} 