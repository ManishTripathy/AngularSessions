import { Component, OnInit } from '@angular/core';
import {DataService} from '../services/data.service';
import {AppConstants} from '../common/app.constants';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
   products: Array<any>

  constructor(private dataSvc : DataService) {//adding private/public before the variable makes it a private/public variable in the class, or else it stays as parameter to the constructor
    this.getProductsAsync();
  }

  ngOnInit() {
  }

  add(item) {
    item.quantity++;
    this.dataSvc.handleCart(item);
  }

   remove(item) {
     item.quantity--;
     this.dataSvc.handleCartRemove(item);
  }

  getProductsAsync() {
    this.dataSvc.getDataFromAPi(AppConstants.PRODUCTS_API)
    .then(res=>{
        console.log(res.products);
        this.products = res.products.map(x=> {
          x.quantity=0;//This map method helps us to add quantity property to all the products inside
          return x;
        });
    })
    .catch(res=> {
      console.log(res);
    })
  }

}
