import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators} from '@angular/forms'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:FormGroup

  constructor(private fb : FormBuilder) { 
    this.loginForm = fb.group({
      //username : [null, Validators.required] // This is for single validations
      username : [null, Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(10)])]
    })
  }

  login() {
    this.loginForm.dirty
    console.log(this.loginForm.controls['username'].value);
  }

  ngOnInit() {
  }

}
