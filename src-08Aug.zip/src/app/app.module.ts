import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations'
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {DataService} from './services/data.service';
import {HttpModule} from '@angular/http';
import {RouterModule} from '@angular/router';
import {DataGridModule, PanelModule, PanelMenuModule,DialogModule, TabViewModule} from 'primeng/primeng';

import { AppComponent } from './app.component';

import { HeaderComponent} from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LogoComponent } from './logo/logo.component';
import { RegisterComponent } from './register/register.component';
import { ProductsComponent } from './products/products.component';
import { CartComponent } from './cart/cart.component';
import { LoginComponent } from './login/login.component';
import { DropdownComponent } from './dropdown/dropdown.component';
import { ProductgridComponent } from './productgrid/productgrid.component';
import { FormatPipe } from './pipe/format.pipe';
import { NumbersOnlyDirective } from './directives/numbersonly.directive';
import { RestrictInputDirective } from './directives/restrictinput.directive';
import { DatePickerDirective } from './directives/datepicker.directive';

var routes=[
    {path:"register", component:RegisterComponent},
    {path:"products", component:ProductsComponent},
    {path:"login", component:LoginComponent},
    {path:"cart", component:CartComponent}
  ];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LogoComponent,
    RegisterComponent,
    ProductsComponent,
    CartComponent,
    LoginComponent,
    DropdownComponent,
    ProductgridComponent,
    FormatPipe,
    NumbersOnlyDirective,
    RestrictInputDirective,
    DatePickerDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    DataGridModule,
    PanelModule, PanelMenuModule,DialogModule, TabViewModule,BrowserAnimationsModule,NoopAnimationsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { } 
