import {Pipe,PipeTransform} from '@angular/core'

@Pipe({
    name : 'phonefomatter'
})
export class FormatPipe implements PipeTransform {
    
    transform(value:any, args?:any): any {
        console.log("From pipe : " + value + "-args:" + args);

        if(args=='inr') {
            return `+91-${value.substring(0,5)}-${value.substring(5,10)}`
        }
        else if(args=='USD') {
            return `+1-${value.substring(0,5)}-${value.substring(5,10)}`
        }
        return value;
    }
}
