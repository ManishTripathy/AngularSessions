import { Component, OnInit } from '@angular/core';
import {DataService} from '../services/data.service';
import {AppConstants} from '../common/app.constants';
import {DropDownConfig} from "../common/dropdown.config";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  profile:any
  countries: Array<any>
  dropdownConfig:DropDownConfig
  subCountries:any
 
  constructor(private dataSvc : DataService) {//adding private/public before the variable makes it a private/public variable in the class, or else it stays as parameter to the constructor
    this.profile = {};
    //this.countries = [ {name:"America", code:"US"},{name:"India", code:"IN"},{name:"Russia", code:"RS"}, {name:"South Africa", code:"SA"}];
    //this.countries = dataSvc.getCountries();           
    this.profile.selectedCountry = "IN";
    this.dropdownConfig = new DropDownConfig();
    this.dropdownConfig.cssClass = "form-control";
    this.dropdownConfig.selectedvalue = "IN";
    //this.getCountriesDropdownAsync();
    this.getCountriesDropdownObservableAsync();
    this.getCountriesAsync();
    

  }
  
  //If I need the injected dataservice outside, I can either use this.dataSvc as this was a private member of class. If the parmaeter is not private/public then follow this.
    /*
    dataService : DataService;
    constructor( dataSvc : DataService) {
    this.profile = {};
    //this.countries = [ {name:"America", code:"US"},{name:"India", code:"IN"},{name:"Russia", code:"RS"}, {name:"South Africa", code:"SA"}];
    this.dataService=dataSvc;
    this.countries = this.dataService.getCountries();           
    this.profile.selectedCountry = "IN";
  }
  */

  register() {
    console.log(this.profile);
  }

  countrychanged(val) {
    console.log(val);
  }

  ngOnInit() {
  }

  getCountriesAsync() {
    this.dataSvc.getDataFromAPi(AppConstants.COUNTRIES_API)
    .then(res=>{
        console.log(res);
        this.countries = res;
    })
    .catch(res=> {
      console.log(res);
    })
  }

  getCountriesDropdownAsync() {
    this.dataSvc.getDataFromAPi(AppConstants.COUNTRIES_API)
    .then(res=>{
        console.log(res);
        this.dropdownConfig.data = res.map(x=>{
          let y = 
          {
            value : x.code,
            text : x.name
          }
          return y;
        })
    })
    .catch(res=> {
      console.log(res);
    })
  }

  getCountriesDropdownObservableAsync() {
    this.subCountries = this.dataSvc.getCountriesFromAPiAsObservable();
    this.subCountries.subscribe(
      (res)=> {
        this.dropdownConfig.data = res.map(x=>{
          let y = 
          {
            value : x.code,
            text : x.name
          }
          return y;
        });
      },
      (err)=> {
        console.log(err);
      }
    )
  }

  loadMoreCountries() {
    this.dropdownConfig = new DropDownConfig();
    this.dropdownConfig.cssClass = "form-control";
    this.dropdownConfig.data.push({value:"CA", text:"Canada"});
  }

}
