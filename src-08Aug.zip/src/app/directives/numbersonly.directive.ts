import {Directive, ElementRef, HostListener} from '@angular/core';

@Directive({
    selector:'[numbersonly]'
})
export class NumbersOnlyDirective {
    constructor(private el : ElementRef) {
        console.log(el.nativeElement);
    }

    @HostListener('keypress',['$event'])
    onkeypressed(e) {
        console.log("Key Pressed");
        console.log(e);

        let regex = new RegExp(/[0-9]$/);
        if(!regex.test(e.key)) {
            e.preventDefault();
        }
    }
}