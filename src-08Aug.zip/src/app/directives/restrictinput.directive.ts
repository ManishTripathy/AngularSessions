import {Directive, ElementRef, HostListener, Input} from '@angular/core';

@Directive({
    selector:'[restrictinput]'
})
export class RestrictInputDirective {
    constructor(private el : ElementRef) {
        console.log(el.nativeElement);
    }

    @Input()
    expression:any

    @HostListener('keypress',['$event'])
    onkeypressed(e) {
        console.log("Key Pressed");
        console.log(e);

        let regex = new RegExp(this.expression);
        if(!regex.test(e.key)) {
            e.preventDefault();
        }
    }
}