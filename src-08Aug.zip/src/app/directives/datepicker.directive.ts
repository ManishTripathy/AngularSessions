import {Directive, ElementRef, HostListener, Input, OnInit } from '@angular/core';
declare var jQuery:any;

@Directive({
    selector:'[datepicker]'
})
export class DatePickerDirective implements OnInit{

    @Input()
    mymaxdate:any;

    @Input() 
    mymindate:any;

    constructor(private el : ElementRef) {
        console.log("con" + this.mymaxdate + " -- " + this.mymindate);
        /*jQuery(this.el.nativeElement).datepicker({
            //maxDate: this.mymaxdate,//"+7d",
            //minDate: this.mymindate//"-7d"
        }
        );
        */
    }

    ngOnInit() {
        console.log("init" + this.mymaxdate + " -- " + this.mymindate);
        jQuery(this.el.nativeElement).datepicker({
            maxDate: this.mymaxdate,//"+7d",
            minDate: this.mymindate//"-7d"
        }
        );
    }
}