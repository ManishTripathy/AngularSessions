import { Component, OnInit } from '@angular/core';
import {DataGridModule} from 'primeng/primeng';

@Component({
  selector: 'app-productgrid',
  templateUrl: './productgrid.component.html',
  styleUrls: ['./productgrid.component.css']
})
export class ProductgridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
