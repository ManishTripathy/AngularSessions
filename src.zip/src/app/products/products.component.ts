import { Component, OnInit } from '@angular/core';
import {DataService} from '../services/data.service';
import {AppConstants} from '../common/app.constants';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
   products: Array<any>

  constructor(private dataSvc : DataService) {//adding private/public before the variable makes it a private/public variable in the class, or else it stays as parameter to the constructor
    this.getProductsAsync();
  }

  ngOnInit() {
  }

  getProductsAsync() {
    this.dataSvc.getDataFromAPi(AppConstants.PRODUCTS_API)
    .then(res=>{
        console.log(res.products);
        this.products = res;
    })
    .catch(res=> {
      console.log(res);
    })
  }

}
