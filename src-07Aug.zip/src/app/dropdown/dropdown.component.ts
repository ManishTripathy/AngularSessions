import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {DropDownConfig} from "../common/dropdown.config";

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {
  @Input()
  configuration : DropDownConfig

  @Output()
  drowpdownchange : EventEmitter<String>

  selectedvalue : String

  valuechanged() {
    //console.log("DD-" + this.configuration.selectedvalue);
    this.drowpdownchange.emit(this.configuration.selectedvalue);
  }

  constructor() { 
    this.configuration = new DropDownConfig();
    this.drowpdownchange = new EventEmitter<String>();
  }

  ngOnInit() {
  }

}
