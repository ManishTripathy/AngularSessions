export class DropDownConfig {
    cssClass:String
    data:Array<any>
    selectedvalue:String

    constructor() {
        this.cssClass = "";
        this.data=[{value:"", text:""}];
        this.selectedvalue = "";
    }
}