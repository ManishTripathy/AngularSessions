import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'app';
  phonenum = '0123456789';
  price = "30000";
  dob=new Date();
  numbersOnlyRegex = /[0-9]$/;
  alphabetsOnlyRegex = /[a-zA-Z]/;

  calmaxdate= '+7d';
  calmindate =  '-7d';

  constructor() {
    this.loadTime();
  }

  loadTime() {
    setInterval(()=> {
      this.dob = new Date();
    },1000);
  }
}
